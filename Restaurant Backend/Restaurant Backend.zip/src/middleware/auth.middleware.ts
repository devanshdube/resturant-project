import { Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { AuthenticatedRequest, SuperAdminJwtPayload } from '../types/index';
import { AppError } from '../utils/helpers';

// ─────────────────────────────────────────────────────────────────────────────
// protectSuperAdmin — JWT access token verify karega
// Usage: router.get('/route', protectSuperAdmin, controller)
// ─────────────────────────────────────────────────────────────────────────────
export const protectSuperAdmin = (
  req: AuthenticatedRequest,
  _res: Response,
  next: NextFunction
): void => {
  try {
    // ── Extract token from Authorization header ───────────────────────────────
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new AppError('Access denied. Token required.', 401);
    }

    const token = authHeader.split(' ')[1];

    if (!token) {
      throw new AppError('Access denied. Token missing.', 401);
    }

    // ── Verify token ──────────────────────────────────────────────────────────
    const decoded = jwt.verify(
      token,
      process.env.JWT_ACCESS_SECRET as string
    ) as SuperAdminJwtPayload;

    // ── Role check ────────────────────────────────────────────────────────────
    if (decoded.role !== 'super_admin') {
      throw new AppError('Access denied. Super Admin only.', 403);
    }

    // ── Attach user to request ────────────────────────────────────────────────
    req.user = decoded;
    next();

  } catch (err) {
    if (err instanceof jwt.JsonWebTokenError) {
      next(new AppError('Invalid token. Please login again.', 401));
    } else if (err instanceof jwt.TokenExpiredError) {
      next(new AppError('Token expired. Please login again.', 401));
    } else {
      next(err);
    }
  }
};
